package OpenChallenge1;

public class MyInfoApp {
	public static void main(String[] args) {
		System.out.println("허 윤");
		System.out.println("만 21세");
		System.out.println("컴퓨터소프트웨어과");
	}
}
